# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "${prefix}/include".split(';') if "${prefix}/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;rospy;std_msgs;message_runtime".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lyhs_can_control_node".split(';') if "-lyhs_can_control_node" != "" else []
PROJECT_NAME = "yhs_can_control"
PROJECT_SPACE_DIR = "/usr/local"
PROJECT_VERSION = "0.0.0"
