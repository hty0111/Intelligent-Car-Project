# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/hty/Desktop/Driving/control_ws/src/yhs_can_control/include".split(';') if "/home/hty/Desktop/Driving/control_ws/src/yhs_can_control/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;rospy;std_msgs;message_runtime".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lyhs_can_control_node".split(';') if "-lyhs_can_control_node" != "" else []
PROJECT_NAME = "yhs_can_control"
PROJECT_SPACE_DIR = "/home/hty/Desktop/Driving/control_ws/src/cmake-build-debug/devel"
PROJECT_VERSION = "0.0.0"
