# generated from genmsg/cmake/pkg-genmsg.context.in

messages_str = "/home/hty/Desktop/Driving/control_ws/src/yhs_can_msgs/msg/ctrl_cmd.msg;/home/hty/Desktop/Driving/control_ws/src/yhs_can_msgs/msg/io_cmd.msg;/home/hty/Desktop/Driving/control_ws/src/yhs_can_msgs/msg/ctrl_fb.msg;/home/hty/Desktop/Driving/control_ws/src/yhs_can_msgs/msg/lr_wheel_fb.msg;/home/hty/Desktop/Driving/control_ws/src/yhs_can_msgs/msg/rr_wheel_fb.msg;/home/hty/Desktop/Driving/control_ws/src/yhs_can_msgs/msg/io_fb.msg;/home/hty/Desktop/Driving/control_ws/src/yhs_can_msgs/msg/odo_fb.msg;/home/hty/Desktop/Driving/control_ws/src/yhs_can_msgs/msg/bms_Infor_fb.msg;/home/hty/Desktop/Driving/control_ws/src/yhs_can_msgs/msg/bms_flag_Infor_fb.msg;/home/hty/Desktop/Driving/control_ws/src/yhs_can_msgs/msg/Drive_MCUEcoder_fb.msg;/home/hty/Desktop/Driving/control_ws/src/yhs_can_msgs/msg/Veh_Diag_fb.msg"
services_str = ""
pkg_name = "yhs_can_msgs"
dependencies_str = "geometry_msgs;sensor_msgs;std_msgs"
langs = "gencpp;geneus;genlisp;gennodejs;genpy"
dep_include_paths_str = "yhs_can_msgs;/home/hty/Desktop/Driving/control_ws/src/yhs_can_msgs/msg;geometry_msgs;/opt/ros/melodic/share/geometry_msgs/cmake/../msg;sensor_msgs;/opt/ros/melodic/share/sensor_msgs/cmake/../msg;std_msgs;/opt/ros/melodic/share/std_msgs/cmake/../msg"
PYTHON_EXECUTABLE = "/usr/bin/python2"
package_has_static_sources = '' == 'TRUE'
genmsg_check_deps_script = "/opt/ros/melodic/share/genmsg/cmake/../../../lib/genmsg/genmsg_check_deps.py"
