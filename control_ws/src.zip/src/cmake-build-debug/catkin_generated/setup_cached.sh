#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH='/home/hty/Desktop/Driving/control_ws/src/cmake-build-debug/devel:/home/hty/Desktop/Driving/control_ws/devel:/opt/ros/melodic:/home/hty/Applications/cmake-install:/home/hty/Applications/cmake-install'
export LD_LIBRARY_PATH="/home/hty/Desktop/Driving/control_ws/src/cmake-build-debug/devel/lib:$LD_LIBRARY_PATH"
export PATH='/opt/ros/melodic/bin:/home/hty/Applications/MATLAB/R2021b/bin:/home/hty/Applications/cmake-install/bin:/home/hty/Applications/cmake-install/bin:/home/hty/anaconda3/bin:/home/hty/anaconda3/condabin:/home/hty/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin'
export PKG_CONFIG_PATH="/home/hty/Desktop/Driving/control_ws/src/cmake-build-debug/devel/lib/pkgconfig:$PKG_CONFIG_PATH"
export PYTHONPATH="/home/hty/Desktop/Driving/control_ws/src/cmake-build-debug/devel/lib/python2.7/dist-packages:$PYTHONPATH"
export ROSLISP_PACKAGE_DIRECTORIES="/home/hty/Desktop/Driving/control_ws/src/cmake-build-debug/devel/share/common-lisp:$ROSLISP_PACKAGE_DIRECTORIES"
export ROS_PACKAGE_PATH="/home/hty/Desktop/Driving/control_ws/src:$ROS_PACKAGE_PATH"